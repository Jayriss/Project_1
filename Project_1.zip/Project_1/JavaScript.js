﻿var board;
var moveUpEvent = document.getElementById("moveUp").offsetTop;
var moveUpEvent1 = document.getElementById("moveUp1").offsetTop;

function movePlayerUp() {
    var x = document.getElementById("playerToken").offsetTop;
    document.getElementById("playerToken").style.position = "absolute";
    x = x + 100;
    document.getElementById("playerToken").style.top = x + "px";
}

//document.getElementById("moveUp").onclick(movePlayerUp);